#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

/*programa que crea dos hijos: uno no cambia de ejecutable y otro si */

// el programa recibe como paremetros el nombre del ejecutable que deberia ejecutrar y los argumentos que necesite para exe
int main(int argc, char **argv)
{
	int status;
	char *buffer[3] = {"ls", "-l", NULL};
	char *const *args = buffer;
	pid_t pid;

	if ((pid = fork()) != 0) // Create a child
	{
		// 1st parent
		waitpid(pid, &status, 0);
		printf("My PID is %d and I am a father, with a child with PID: %d\n", getpid(), (int)pid);
		if ((pid = fork()) != 0){ // 2nd parent
			waitpid(pid, &status, 0);
			printf("My PID is %d and I am a father, with a child with PID: %d\n", getpid(), (int)pid);
		} else { // 2nd child
			execvp(args[0], args);
		}
		
	} else { // 1st child
		printf("My PID is %d and I am a child, my father has PID: %d \n", (int)getpid(), (int)getppid());
	}

	return EXIT_SUCCESS;
}
